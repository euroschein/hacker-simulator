import { ObjectId } from 'mongodb';
import {
    route, HttpError, getBody, getSessionUser, requireUser, adjustGems,
} from './_lib.js';

const ALLOWED_COLORS = ['red', 'orange', 'yellow', 'green', 'blue', 'purple'];
const MAX_OPEN_GAMES = 5;
const MAX_WAGER = 1_000_000_000;

export default route(async (req, res, db) => {
    const games = db.collection('games');

    // --- Offene Spiele auflisten (öffentlich, Session optional) ---
    if (req.method === 'GET') {
        const viewer = await getSessionUser(db, req);
        // "escrowed: true" blendet alte Spiele aus der Zeit vor dem Gem-System aus
        const open = await games
            .find({ status: 'waiting', escrowed: true })
            .sort({ createdAt: -1 })
            .limit(50)
            .toArray();

        return res.status(200).json({
            success: true,
            games: open.map((g) => ({
                _id: g._id,
                creatorName: g.creatorName,
                creatorAvatar: g.creatorAvatar,
                wager: g.wager,
                firstTo: g.firstTo,
                colors: g.colors,
                ruleTitanic: g.ruleTitanic,
                createdAt: g.createdAt,
                isMine: !!viewer && viewer.userId === g.creatorId,
            })),
        });
    }

    // --- Spiel erstellen: Einsatz wird sofort vom Guthaben abgezogen (Escrow) ---
    if (req.method === 'POST') {
        const user = await requireUser(db, req);
        const body = getBody(req);

        const wager = body.wager;
        const firstTo = body.firstTo;
        const colors = body.colors;

        if (!Number.isInteger(wager) || wager < 1 || wager > MAX_WAGER) {
            throw new HttpError(400, 'Invalid wager.');
        }
        if (![1, 2, 3].includes(firstTo)) throw new HttpError(400, 'Invalid "first to" value.');
        if (
            !Array.isArray(colors) ||
            colors.length < 1 || colors.length > 2 ||
            new Set(colors).size !== colors.length ||
            !colors.every((c) => ALLOWED_COLORS.includes(c))
        ) {
            throw new HttpError(400, 'Pick 1 or 2 valid colors.');
        }

        const openCount = await games.countDocuments({ creatorId: user.userId, status: 'waiting' });
        if (openCount >= MAX_OPEN_GAMES) {
            throw new HttpError(429, `You can only have ${MAX_OPEN_GAMES} open rooms at once.`);
        }

        // ID vorab erzeugen, damit das Ledger den Einsatz diesem Spiel zuordnen kann
        const gameId = new ObjectId();
        const balance = await adjustGems(db, user.userId, -wager, 'game_escrow', String(gameId));
        if (balance === null) throw new HttpError(402, "You don't have enough gems.");

        try {
            await games.insertOne({
                _id: gameId,
                // Name/Avatar kommen aus der Session, nie vom Client
                creatorId: user.userId,
                creatorName: user.username,
                creatorAvatar: user.avatar || '',
                wager,
                firstTo,
                colors,
                ruleTitanic: body.ruleTitanic === true,
                status: 'waiting',
                escrowed: true,
                createdAt: new Date(),
            });
            return res.status(200).json({ success: true, gameId, gems: balance });
        } catch (err) {
            // Einsatz zurück, falls das Speichern scheitert
            await adjustGems(db, user.userId, wager, 'game_refund', String(gameId));
            throw err;
        }
    }

    // --- Eigenes wartendes Spiel abbrechen: Einsatz zurück ---
    if (req.method === 'DELETE') {
        const user = await requireUser(db, req);
        const id = String(req.query.id || '');
        if (!ObjectId.isValid(id)) throw new HttpError(400, 'Invalid game id.');

        // Atomar löschen -> nur ein Request kann die Rückerstattung auslösen (kein Doppel-Refund)
        const removed = await games.findOneAndDelete({
            _id: new ObjectId(id),
            creatorId: user.userId,
            status: 'waiting',
            escrowed: true,
        });
        if (!removed) throw new HttpError(404, 'Game not found or already started.');

        const balance = await adjustGems(db, user.userId, removed.wager, 'game_refund', id);
        return res.status(200).json({ success: true, gems: balance });
    }

    throw new HttpError(405, 'Method not allowed.');
});
