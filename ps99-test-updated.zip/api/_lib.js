// Gemeinsame Helfer für alle API-Routen.
// Dateien mit "_" am Anfang werden von Vercel NICHT als eigene Route veröffentlicht.
import { MongoClient } from 'mongodb';
import crypto from 'crypto';

export const START_GEMS = 1000;
export const SESSION_DAYS = 30;
const COOKIE_NAME = 'bl_session';

export class HttpError extends Error {
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}

/* ---------- Datenbank ---------- */

let clientPromise = null;
let indexesReady = false;

export async function getDb() {
    const uri = process.env.MONGODB_URI;
    if (!uri) throw new Error('MONGODB_URI is missing in Vercel settings');

    if (!clientPromise) {
        clientPromise = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 })
            .connect()
            .catch((err) => {
                clientPromise = null; // beim nächsten Request neu versuchen
                throw err;
            });
    }
    const client = await clientPromise;
    const db = client.db('bloxylucky');

    if (!indexesReady) {
        indexesReady = true;
        await ensureIndexes(db);
    }
    return db;
}

async function ensureIndexes(db) {
    try {
        await Promise.all([
            db.collection('users').createIndex({ userId: 1 }, { unique: true }),
            db.collection('sessions').createIndex({ tokenHash: 1 }, { unique: true }),
            // TTL: MongoDB löscht abgelaufene Sessions / Login-Challenges automatisch
            db.collection('sessions').createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 }),
            db.collection('login_challenges').createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 }),
            db.collection('transactions').createIndex({ userId: 1, createdAt: -1 }),
            db.collection('games').createIndex({ status: 1, createdAt: -1 }),
        ]);
    } catch (err) {
        // Ein fehlgeschlagener Index (z.B. Duplikate in alten Daten) darf die API nicht lahmlegen
        console.error('Index setup failed:', err.message);
    }
}

/* ---------- Request-Helfer ---------- */

export function getBody(req) {
    return req.body && typeof req.body === 'object' ? req.body : {};
}

// Schützt vor Cross-Site-Anfragen (zusätzlich zu SameSite=Lax beim Cookie)
function requireSameOrigin(req) {
    const origin = req.headers.origin;
    if (!origin) return;
    let host;
    try {
        host = new URL(origin).host;
    } catch {
        throw new HttpError(403, 'Bad origin');
    }
    if (host !== req.headers.host) throw new HttpError(403, 'Bad origin');
}

// Wrapper: setzt Header, prüft Origin, verbindet DB, fängt Fehler ab
export function route(fn) {
    return async (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Cache-Control', 'no-store');
        try {
            if (req.method !== 'GET' && req.method !== 'HEAD') requireSameOrigin(req);
            const db = await getDb();
            await fn(req, res, db);
        } catch (err) {
            if (!err.status) console.error('API Error:', err);
            res.status(err.status || 500).json({
                success: false,
                error: err.status ? err.message : 'Server error',
            });
        }
    };
}

/* ---------- Sessions ---------- */

function parseCookies(header = '') {
    const out = {};
    header.split(';').forEach((part) => {
        const i = part.indexOf('=');
        if (i > 0) {
            try {
                out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
            } catch {
                /* kaputtes Cookie ignorieren */
            }
        }
    });
    return out;
}

// In der DB steht nur der Hash des Tokens. Selbst bei einem DB-Leak sind keine Sessions klaubar.
const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');

function cookieString(req, value, maxAgeSeconds) {
    const host = req.headers.host || '';
    const secure = !/^(localhost|127\.0\.0\.1)/.test(host);
    return `${COOKIE_NAME}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}${secure ? '; Secure' : ''}`;
}

export async function createSession(db, req, res, userId) {
    const token = crypto.randomBytes(32).toString('hex');
    const now = new Date();
    await db.collection('sessions').insertOne({
        tokenHash: hashToken(token),
        userId,
        createdAt: now,
        expiresAt: new Date(now.getTime() + SESSION_DAYS * 86400000),
    });
    res.setHeader('Set-Cookie', cookieString(req, token, SESSION_DAYS * 86400));
}

export async function destroySession(db, req, res) {
    const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
    if (token) await db.collection('sessions').deleteOne({ tokenHash: hashToken(token) });
    res.setHeader('Set-Cookie', cookieString(req, '', 0));
}

export async function getSessionUser(db, req) {
    const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
    if (!token || token.length !== 64) return null;

    const session = await db.collection('sessions').findOne({ tokenHash: hashToken(token) });
    if (!session || session.expiresAt < new Date()) return null;

    return db.collection('users').findOne({ userId: session.userId });
}

export async function requireUser(db, req) {
    const user = await getSessionUser(db, req);
    if (!user) throw new HttpError(401, 'Not logged in');
    return user;
}

export function publicUser(user) {
    return {
        userId: user.userId,
        username: user.username,
        avatar: user.avatar || '',
        gems: user.gems ?? 0,
    };
}

/* ---------- Gem-Guthaben ---------- */

// Einzige Stelle, an der Gems verändert werden. Atomar: ein Abzug schlägt fehl,
// wenn das Guthaben nicht reicht (kein Minus-Guthaben, keine Race Conditions).
// Jede Änderung landet im Ledger ("transactions").
// Gibt das neue Guthaben zurück oder null, wenn nicht genug Gems da sind.
export async function adjustGems(db, userId, delta, type, ref = null) {
    if (!Number.isSafeInteger(delta) || delta === 0) throw new Error('Invalid gem amount');

    const filter = { userId };
    if (delta < 0) filter.gems = { $gte: -delta };

    const updated = await db
        .collection('users')
        .findOneAndUpdate(filter, { $inc: { gems: delta } }, { returnDocument: 'after' });
    if (!updated) return null;

    await db.collection('transactions').insertOne({
        userId,
        type,
        amount: delta,
        balanceAfter: updated.gems,
        ref,
        createdAt: new Date(),
    });
    return updated.gems;
}
