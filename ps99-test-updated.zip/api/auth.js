import crypto from 'crypto';
import {
    route, HttpError, getBody, createSession, destroySession,
    getSessionUser, publicUser, START_GEMS,
} from './_lib.js';

const CHALLENGE_MINUTES = 10;
const MAX_VERIFY_ATTEMPTS = 150; // bei 5s-Polling reicht das für die 10 Minuten

async function robloxJson(url, options = {}) {
    let res;
    try {
        res = await fetch(url, { ...options, signal: AbortSignal.timeout(8000) });
    } catch {
        throw new HttpError(502, 'Roblox is not reachable, please try again.');
    }
    if (!res.ok) throw new HttpError(502, 'Roblox API error, please try again.');
    return res.json();
}

function newPhrase() {
    // 6 Zeichen aus einem eindeutigen Alphabet (ohne 0/O/1/I)
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const bytes = crypto.randomBytes(6);
    let out = '';
    for (const b of bytes) out += alphabet[b % alphabet.length];
    return `BL-${out}`;
}

export default route(async (req, res, db) => {
    const action = req.query.action;

    // --- Wer bin ich? (stellt die Session beim Seitenaufruf wieder her) ---
    if (action === 'me' && req.method === 'GET') {
        const user = await getSessionUser(db, req);
        return res.status(200).json({ success: true, user: user ? publicUser(user) : null });
    }

    // --- Schritt 1: Username prüfen, Phrase erzeugen ---
    if (action === 'start' && req.method === 'POST') {
        const username = String(getBody(req).username || '').trim();
        if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
            throw new HttpError(400, 'Invalid Roblox username.');
        }

        const found = await robloxJson('https://users.roblox.com/v1/usernames/users', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usernames: [username], excludeBannedUsers: true }),
        });
        const robloxUser = found.data && found.data[0];
        if (!robloxUser) throw new HttpError(404, 'Roblox user not found.');

        const userId = Number(robloxUser.id);
        const challengeId = crypto.randomBytes(16).toString('hex');
        const phrase = newPhrase();
        const now = new Date();

        const challenges = db.collection('login_challenges');
        await challenges.deleteMany({ userId }); // pro User nur eine offene Challenge
        await challenges.insertOne({
            _id: challengeId,
            userId,
            username: robloxUser.name, // korrekte Schreibweise von Roblox
            phrase,
            attempts: 0,
            createdAt: now,
            expiresAt: new Date(now.getTime() + CHALLENGE_MINUTES * 60000),
        });

        return res.status(200).json({ success: true, challengeId, phrase, username: robloxUser.name });
    }

    // --- Schritt 2: Bio serverseitig prüfen, Session anlegen ---
    if (action === 'verify' && req.method === 'POST') {
        const challengeId = String(getBody(req).challengeId || '');
        if (!/^[a-f0-9]{32}$/.test(challengeId)) throw new HttpError(400, 'Invalid challenge.');

        const challenges = db.collection('login_challenges');
        const challenge = await challenges.findOne({ _id: challengeId });
        if (!challenge || challenge.expiresAt < new Date()) {
            throw new HttpError(410, 'Login expired, please start again.');
        }
        if (challenge.attempts >= MAX_VERIFY_ATTEMPTS) {
            await challenges.deleteOne({ _id: challengeId });
            throw new HttpError(429, 'Too many attempts, please start again.');
        }
        await challenges.updateOne({ _id: challengeId }, { $inc: { attempts: 1 } });

        const profile = await robloxJson(`https://users.roblox.com/v1/users/${challenge.userId}`);
        if (!String(profile.description || '').includes(challenge.phrase)) {
            return res.status(200).json({ success: true, verified: false });
        }

        // Verifiziert -> Avatar holen (optional) und User anlegen/aktualisieren
        let avatar = '';
        try {
            const thumb = await robloxJson(
                `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${challenge.userId}&size=150x150&format=Png&isCircular=true`
            );
            avatar = (thumb.data && thumb.data[0] && thumb.data[0].imageUrl) || '';
        } catch {
            /* Avatar ist nicht kritisch */
        }

        const users = db.collection('users');
        const now = new Date();
        const upsert = await users.updateOne(
            { userId: challenge.userId },
            {
                $set: { username: challenge.username, avatar, lastLogin: now },
                $setOnInsert: { createdAt: now, gems: START_GEMS },
            },
            { upsert: true }
        );

        // Neuer User -> Startguthaben ins Ledger. Alter User ohne Guthaben-Feld -> nachtragen.
        let bonusGranted = upsert.upsertedCount === 1;
        if (!bonusGranted) {
            const legacy = await users.updateOne(
                { userId: challenge.userId, gems: { $exists: false } },
                { $set: { gems: START_GEMS } }
            );
            bonusGranted = legacy.modifiedCount === 1;
        }
        if (bonusGranted) {
            await db.collection('transactions').insertOne({
                userId: challenge.userId,
                type: 'signup_bonus',
                amount: START_GEMS,
                balanceAfter: START_GEMS,
                ref: null,
                createdAt: now,
            });
        }

        await challenges.deleteOne({ _id: challengeId });
        await createSession(db, req, res, challenge.userId);

        const user = await users.findOne({ userId: challenge.userId });
        return res.status(200).json({ success: true, verified: true, user: publicUser(user) });
    }

    // --- Logout ---
    if (action === 'logout' && req.method === 'POST') {
        await destroySession(db, req, res);
        return res.status(200).json({ success: true });
    }

    throw new HttpError(400, 'Invalid action.');
});
